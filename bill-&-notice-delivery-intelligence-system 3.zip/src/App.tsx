/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './lib/auth';
import LoginScreen from './screens/LoginScreen';
import AgentDashboardScreen from './screens/AgentDashboardScreen';
import ScanScreen from './screens/ScanScreen';
import CreateCustomerScreen from './screens/CreateCustomerScreen';
import DeliveryConfirmationScreen from './screens/DeliveryConfirmationScreen';
import AdminDashboardScreen from './screens/AdminDashboardScreen';
import MapScreen from './screens/MapScreen';
import ReportsScreen from './screens/ReportsScreen';
import MasterDataScreen from './screens/MasterDataScreen';
import AgentManagementScreen from './screens/AgentManagementScreen';

const ProtectedRoute = ({ children, allowedRole }: { children: React.ReactNode, allowedRole: 'ADMIN' | 'AGENT' | 'ANY' }) => {
  const { user, role, loading } = useAuth();

  if (loading) return <div className="flex items-center justify-center h-screen">Loading...</div>;
  if (!user) return <Navigate to="/" replace />;
  if (allowedRole !== 'ANY' && role !== allowedRole && role !== 'ADMIN') {
    // Admin can access agent routes
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

const RootRedirect = () => {
  const { user, role, loading } = useAuth();
  
  if (loading) return <div className="flex items-center justify-center h-screen">Loading...</div>;
  if (user && role) {
    return <Navigate to={role === 'ADMIN' ? '/admin' : '/agent'} replace />;
  }
  return <LoginScreen />;
};

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
          <Routes>
            <Route path="/" element={<RootRedirect />} />
            
            {/* Agent Routes */}
            <Route path="/agent" element={<ProtectedRoute allowedRole="AGENT"><AgentDashboardScreen /></ProtectedRoute>} />
            <Route path="/scan" element={<ProtectedRoute allowedRole="AGENT"><ScanScreen /></ProtectedRoute>} />
            <Route path="/create-customer" element={<ProtectedRoute allowedRole="AGENT"><CreateCustomerScreen /></ProtectedRoute>} />
            <Route path="/confirm-delivery" element={<ProtectedRoute allowedRole="AGENT"><DeliveryConfirmationScreen /></ProtectedRoute>} />

            {/* Admin Routes */}
            <Route path="/admin" element={<ProtectedRoute allowedRole="ADMIN"><AdminDashboardScreen /></ProtectedRoute>} />
            <Route path="/admin/map" element={<ProtectedRoute allowedRole="ADMIN"><MapScreen /></ProtectedRoute>} />
            <Route path="/admin/reports" element={<ProtectedRoute allowedRole="ADMIN"><ReportsScreen /></ProtectedRoute>} />
            <Route path="/admin/master-data" element={<ProtectedRoute allowedRole="ADMIN"><MasterDataScreen /></ProtectedRoute>} />
            <Route path="/admin/agents" element={<ProtectedRoute allowedRole="ADMIN"><AgentManagementScreen /></ProtectedRoute>} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

