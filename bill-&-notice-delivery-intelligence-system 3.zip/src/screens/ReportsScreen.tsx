import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Download, Filter, Image as ImageIcon, X } from 'lucide-react';
import { db } from '../lib/db';
import { useLiveQuery } from 'dexie-react-hooks';
import Papa from 'papaparse';

export default function ReportsScreen() {
  const navigate = useNavigate();
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [filterType, setFilterType] = useState<string>('ALL');
  const [filterAgent, setFilterAgent] = useState<string>('ALL');
  
  const [viewImage, setViewImage] = useState<{ url: string, title: string } | null>(null);

  const [columns, setColumns] = useState({
    bpNumber: true,
    noticeNumber: true,
    customerName: true,
    deliveryType: true,
    agentName: true,
    timestamp: true,
    latitude: true,
    longitude: true,
    receiverName: true,
    syncStatus: true,
    hasSignature: true,
    hasPhoto: true
  });

  const deliveries = useLiveQuery(() => db.deliveries.toArray()) || [];
  
  const uniqueAgents = Array.from(new Set(deliveries.map(d => d.agentId)));

  const filteredDeliveries = deliveries.filter(d => {
    const dDate = d.timestamp.split('T')[0];
    if (startDate && dDate < startDate) return false;
    if (endDate && dDate > endDate) return false;
    if (filterType !== 'ALL' && d.deliveryType !== filterType) return false;
    if (filterAgent !== 'ALL' && d.agentId !== filterAgent) return false;
    return true;
  }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const handleExport = () => {
    const dataToExport = filteredDeliveries.map(d => {
      const row: any = {};
      if (columns.bpNumber) row['BP Number'] = d.bpNumber;
      if (columns.noticeNumber) row['Notice Number'] = d.noticeNumber || '';
      if (columns.customerName) row['Customer Name'] = d.customerName;
      if (columns.deliveryType) row['Delivery Type'] = d.deliveryType;
      if (columns.agentName) row['Agent Name'] = d.agentName;
      if (columns.timestamp) row['Timestamp'] = new Date(d.timestamp).toLocaleString();
      if (columns.latitude) row['Latitude'] = d.latitude;
      if (columns.longitude) row['Longitude'] = d.longitude;
      if (columns.receiverName) row['Receiver Name'] = d.receiverName;
      if (columns.syncStatus) row['Sync Status'] = d.syncStatus;
      if (columns.hasSignature) row['Has Signature'] = d.signatureBase64 ? 'Yes' : 'No';
      if (columns.hasPhoto) row['Has Photo'] = d.photoBase64 ? 'Yes' : 'No';
      return row;
    });

    const csv = Papa.unparse(dataToExport);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `deliveries_report_${startDate}_to_${endDate}.csv`;
    link.click();
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col relative">
      <header className="bg-gray-900 text-white p-4 shadow-md flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 hover:bg-gray-800 rounded-full">
          <ArrowLeft className="w-6 h-6 text-gray-300" />
        </button>
        <h1 className="text-xl font-bold">Reports & Export</h1>
      </header>

      <main className="flex-1 p-4 max-w-4xl mx-auto w-full space-y-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2 mb-4">
            <Filter className="w-5 h-5 text-gray-500" /> Filters
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full border-gray-300 rounded-xl p-3 bg-gray-50 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full border-gray-300 rounded-xl p-3 bg-gray-50 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="w-full border-gray-300 rounded-xl p-3 bg-gray-50 focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="ALL">All Types</option>
                <option value="BILL">Bill Only</option>
                <option value="NOTICE">Notice Only</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Agent</label>
              <select
                value={filterAgent}
                onChange={(e) => setFilterAgent(e.target.value)}
                className="w-full border-gray-300 rounded-xl p-3 bg-gray-50 focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="ALL">All Agents</option>
                {uniqueAgents.map(agent => (
                  <option key={agent} value={agent}>{agent}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h2 className="text-lg font-bold text-gray-900 mb-4">Export Columns</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {Object.keys(columns).map((col) => (
              <label key={col} className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={columns[col as keyof typeof columns]}
                  onChange={(e) => setColumns({ ...columns, [col]: e.target.checked })}
                  className="w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                />
                {col.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
              </label>
            ))}
          </div>

          <button
            onClick={handleExport}
            disabled={filteredDeliveries.length === 0}
            className="w-full mt-6 bg-green-600 hover:bg-green-700 text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
          >
            <Download className="w-5 h-5" />
            Export {filteredDeliveries.length} Records to CSV
          </button>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-gray-500">
              <thead className="text-xs text-gray-700 uppercase bg-gray-50 border-b">
                <tr>
                  <th className="px-6 py-3">BP Number</th>
                  <th className="px-6 py-3">Type</th>
                  <th className="px-6 py-3">Customer</th>
                  <th className="px-6 py-3">Time</th>
                  <th className="px-6 py-3">Proof</th>
                  <th className="px-6 py-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {filteredDeliveries.slice(0, 50).map((d, i) => (
                  <tr key={i} className="bg-white border-b hover:bg-gray-50">
                    <td className="px-6 py-4 font-medium text-gray-900">{d.bpNumber}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 text-xs font-bold rounded-md ${d.deliveryType === 'BILL' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>
                        {d.deliveryType}
                      </span>
                    </td>
                    <td className="px-6 py-4">{d.customerName}</td>
                    <td className="px-6 py-4">{new Date(d.timestamp).toLocaleString()}</td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        {d.signatureBase64 && (
                          <button 
                            onClick={() => setViewImage({ url: d.signatureBase64, title: `Signature - ${d.bpNumber}` })}
                            className="px-2 py-1 bg-gray-100 hover:bg-gray-200 rounded text-xs font-medium transition-colors"
                            title="View Signature"
                          >
                            Sig
                          </button>
                        )}
                        {d.photoBase64 && (
                          <button 
                            onClick={() => setViewImage({ url: d.photoBase64!, title: `Photo - ${d.bpNumber}` })}
                            className="p-1 bg-blue-50 hover:bg-blue-100 rounded text-blue-600 transition-colors"
                            title="View Photo"
                          >
                            <ImageIcon className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 text-xs font-bold rounded-md ${d.syncStatus === 'SYNCED' ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}`}>
                        {d.syncStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredDeliveries.length > 50 && (
              <div className="p-4 text-center text-sm text-gray-500 bg-gray-50">
                Showing 50 of {filteredDeliveries.length} records. Export to see all.
              </div>
            )}
            {filteredDeliveries.length === 0 && (
              <div className="p-8 text-center text-sm text-gray-500">
                No records found for the selected filters.
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Image Modal */}
      {viewImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b">
              <h3 className="font-bold text-gray-900">{viewImage.title}</h3>
              <button 
                onClick={() => setViewImage(null)}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
            <div className="p-4 flex justify-center bg-gray-50">
              <img src={viewImage.url} alt={viewImage.title} className="max-h-[60vh] object-contain rounded-lg border border-gray-200" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
