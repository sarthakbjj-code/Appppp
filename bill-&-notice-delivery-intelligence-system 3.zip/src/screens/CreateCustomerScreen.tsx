import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft, UserPlus } from 'lucide-react';
import { db } from '../lib/db';
import { useAuth } from '../lib/auth';
import { logAudit } from '../lib/sync';

export default function CreateCustomerScreen() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const stateData = location.state as any;

  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);

  if (!stateData?.bpNumber) {
    navigate('/scan');
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const newCustomer = {
      bpNumber: stateData.bpNumber,
      customerName: name,
      address,
      phone,
      deliveryCount: 0,
      lastDeliveredAt: null,
      lastLatitude: null,
      lastLongitude: null,
      createdBy: user?.uid || 'unknown',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      syncStatus: 'PENDING' as const
    };

    try {
      await db.customers.put(newCustomer);
      await logAudit('CUSTOMER_CREATED', user?.uid || 'unknown', newCustomer, stateData.bpNumber);
      
      // Proceed to delivery confirmation
      navigate('/confirm-delivery', { 
        state: { ...stateData, customer: newCustomer },
        replace: true
      });
    } catch (err) {
      console.error(err);
      alert("Failed to save customer data.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white p-4 shadow-sm flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 hover:bg-gray-100 rounded-full">
          <ArrowLeft className="w-6 h-6 text-gray-700" />
        </button>
        <h1 className="text-xl font-bold text-gray-900">New Customer</h1>
      </header>

      <main className="flex-1 p-4 max-w-md mx-auto w-full">
        <div className="bg-blue-50 text-blue-800 p-4 rounded-xl mb-6 flex items-start gap-3 text-sm">
          <UserPlus className="w-5 h-5 shrink-0 mt-0.5" />
          <p>Customer BP <strong>{stateData.bpNumber}</strong> not found. Please create a new record to continue delivery.</p>
        </div>

        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Customer Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full border-gray-300 rounded-xl p-3 bg-gray-50 focus:ring-2 focus:ring-blue-500 outline-none"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
            <textarea
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full border-gray-300 rounded-xl p-3 bg-gray-50 focus:ring-2 focus:ring-blue-500 outline-none"
              rows={3}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
              className="w-full border-gray-300 rounded-xl p-3 bg-gray-50 focus:ring-2 focus:ring-blue-500 outline-none"
              maxLength={15}
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-medium mt-6 transition-colors disabled:opacity-50"
          >
            {loading ? 'Saving...' : 'Save & Continue'}
          </button>
        </form>
      </main>
    </div>
  );
}
