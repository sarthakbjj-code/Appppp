import React, { useState, useEffect } from 'react';
import { useAuth } from '../lib/auth';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, UserPlus, Trash2, Mail, Shield } from 'lucide-react';
import { dbRealtime } from '../lib/firebase';
import { ref, get, set, remove, query, orderByChild, equalTo } from 'firebase/database';

interface Agent {
  email: string;
  role: string;
  createdAt?: string;
}

export default function AgentManagementScreen() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [newEmail, setNewEmail] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchAgents();
  }, []);

  const fetchAgents = async () => {
    try {
      const agentsQuery = query(ref(dbRealtime, 'users'), orderByChild('role'), equalTo('AGENT'));
      const snapshot = await get(agentsQuery);
      
      const agentsList: Agent[] = [];
      if (snapshot.exists()) {
        snapshot.forEach(child => {
          agentsList.push(child.val() as Agent);
        });
      }
      setAgents(agentsList);
    } catch (err) {
      console.error("Error fetching agents:", err);
      setError("Failed to load agents.");
    } finally {
      setLoading(false);
    }
  };

  const handleAddAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    
    if (!newEmail || !newEmail.includes('@')) {
      setError('Please enter a valid email address.');
      return;
    }

    try {
      const safeEmail = newEmail.toLowerCase().replace(/[.#$[\]]/g, '_');
      await set(ref(dbRealtime, `users/${safeEmail}`), {
        email: newEmail.toLowerCase(),
        role: 'AGENT',
        createdAt: new Date().toISOString()
      });
      setSuccess(`Agent ${newEmail} added successfully!`);
      setNewEmail('');
      fetchAgents();
    } catch (err) {
      console.error("Error adding agent:", err);
      setError("Failed to add agent.");
    }
  };

  const handleRemoveAgent = async (email: string) => {
    if (!window.confirm(`Are you sure you want to remove ${email}? They will no longer be able to log in.`)) {
      return;
    }

    try {
      const safeEmail = email.toLowerCase().replace(/[.#$[\]]/g, '_');
      await remove(ref(dbRealtime, `users/${safeEmail}`));
      setSuccess(`Agent ${email} removed.`);
      fetchAgents();
    } catch (err) {
      console.error("Error removing agent:", err);
      setError("Failed to remove agent.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <header className="bg-gray-900 text-white p-4 shadow-md flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate('/admin')} className="p-2 hover:bg-gray-800 rounded-full transition">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold">Agent Management</h1>
      </header>

      <main className="p-4 max-w-4xl mx-auto space-y-6 mt-4">
        {/* Add Agent Form */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-blue-600" />
            Authorize New Agent
          </h2>
          
          <form onSubmit={handleAddAgent} className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1 relative">
              <Mail className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                placeholder="agent@gmail.com"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                required
              />
            </div>
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-medium transition-colors whitespace-nowrap"
            >
              Add Agent
            </button>
          </form>

          {error && <p className="text-red-600 text-sm mt-3">{error}</p>}
          {success && <p className="text-green-600 text-sm mt-3">{success}</p>}
        </div>

        {/* Agent List */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-4 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
            <h2 className="font-bold text-gray-900 flex items-center gap-2">
              <Shield className="w-5 h-5 text-gray-500" />
              Authorized Agents
            </h2>
            <span className="bg-blue-100 text-blue-800 text-xs font-bold px-2 py-1 rounded-full">
              {agents.length} Total
            </span>
          </div>

          {loading ? (
            <div className="p-8 text-center text-gray-500">Loading agents...</div>
          ) : agents.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              No agents authorized yet. Add an email above.
            </div>
          ) : (
            <ul className="divide-y divide-gray-100">
              {agents.map((agent) => (
                <li key={agent.email} className="p-4 flex items-center justify-between hover:bg-gray-50 transition-colors">
                  <div>
                    <p className="font-medium text-gray-900">{agent.email}</p>
                    <p className="text-xs text-gray-500">
                      Added: {agent.createdAt ? new Date(agent.createdAt).toLocaleDateString() : 'Unknown'}
                    </p>
                  </div>
                  <button
                    onClick={() => handleRemoveAgent(agent.email)}
                    className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                    title="Remove Agent"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </main>
    </div>
  );
}
