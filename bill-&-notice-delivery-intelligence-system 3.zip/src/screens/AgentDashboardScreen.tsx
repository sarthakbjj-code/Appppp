import React, { useEffect, useState } from 'react';
import { useAuth } from '../lib/auth';
import { useNavigate } from 'react-router-dom';
import { LogOut, QrCode, RefreshCw, CheckCircle2, Clock } from 'lucide-react';
import { db } from '../lib/db';
import { syncToCloud, syncFromCloud } from '../lib/sync';
import { useLiveQuery } from 'dexie-react-hooks';
import { useLiveLocation } from '../lib/location';

export default function AgentDashboardScreen() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [syncing, setSyncing] = useState(false);

  useLiveLocation();

  const todayStr = new Date().toISOString().split('T')[0];
  
  const todayDeliveries = useLiveQuery(
    () => db.deliveries.filter(d => d.timestamp.startsWith(todayStr)).toArray()
  );

  const pendingSync = useLiveQuery(
    () => db.deliveries.where('syncStatus').equals('PENDING').count()
  );

  const handleSync = async () => {
    setSyncing(true);
    await syncToCloud();
    await syncFromCloud();
    setSyncing(false);
  };

  useEffect(() => {
    // Auto sync on mount
    handleSync();
  }, []);

  return (
    <div className="min-h-screen pb-20">
      <header className="bg-blue-600 text-white p-4 shadow-md flex justify-between items-center sticky top-0 z-10">
        <div>
          <h1 className="text-xl font-bold">Agent Dashboard</h1>
          <p className="text-sm text-blue-100">{user?.displayName || user?.email}</p>
        </div>
        <button onClick={logout} className="p-2 hover:bg-blue-700 rounded-full transition">
          <LogOut className="w-5 h-5" />
        </button>
      </header>

      <main className="p-4 space-y-6 max-w-md mx-auto">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center">
            <CheckCircle2 className="w-8 h-8 text-green-500 mb-2" />
            <span className="text-2xl font-bold text-gray-900">{todayDeliveries?.length || 0}</span>
            <span className="text-xs text-gray-500 uppercase tracking-wider">Today's Deliveries</span>
          </div>
          
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center">
            <Clock className="w-8 h-8 text-orange-500 mb-2" />
            <span className="text-2xl font-bold text-gray-900">{pendingSync || 0}</span>
            <span className="text-xs text-gray-500 uppercase tracking-wider">Pending Sync</span>
          </div>
        </div>

        <button
          onClick={() => navigate('/scan')}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-2xl shadow-lg flex flex-col items-center justify-center gap-2 transition-transform active:scale-95"
        >
          <QrCode className="w-10 h-10" />
          <span className="text-lg font-semibold">Start New Delivery</span>
        </button>

        <button
          onClick={handleSync}
          disabled={syncing}
          className="w-full bg-white border border-gray-200 text-gray-700 py-3 rounded-xl flex items-center justify-center gap-2 hover:bg-gray-50 transition-colors disabled:opacity-50"
        >
          <RefreshCw className={`w-5 h-5 ${syncing ? 'animate-spin' : ''}`} />
          {syncing ? 'Syncing...' : 'Sync Now'}
        </button>
      </main>
    </div>
  );
}
