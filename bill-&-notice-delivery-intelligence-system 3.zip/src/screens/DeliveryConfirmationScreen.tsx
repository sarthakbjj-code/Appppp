import React, { useState, useRef, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft, MapPin, CheckCircle2, AlertCircle, Camera, X } from 'lucide-react';
import { db } from '../lib/db';
import { useAuth } from '../lib/auth';
import { logAudit, syncToCloud } from '../lib/sync';

export default function DeliveryConfirmationScreen() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user } = useAuth();
  const stateData = location.state as any;

  const [receiverName, setReceiverName] = useState('');
  const [gps, setGps] = useState<{ lat: number; lng: number } | null>(null);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [photoBase64, setPhotoBase64] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!stateData?.bpNumber || !stateData?.customer) {
    navigate('/scan');
    return null;
  }

  const { bpNumber, deliveryType, noticeNumber, customer } = stateData;

  const fetchGps = () => {
    setGpsError(null);
    if (!navigator.geolocation) {
      setGpsError("Geolocation is not supported by your browser");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setGps({ lat: position.coords.latitude, lng: position.coords.longitude });
      },
      (error) => {
        setGpsError("Failed to get location. Please allow GPS access.");
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  useEffect(() => {
    fetchGps();
  }, []);

  const handlePhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Compress image using canvas
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 800;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        
        // Convert to base64 with moderate quality
        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.7);
        setPhotoBase64(compressedBase64);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    const hasName = receiverName.trim().length > 0;
    const hasPhoto = !!photoBase64;

    if (!hasName && !hasPhoto) {
      alert("Please provide either a receiver name or a photo as proof of delivery.");
      return;
    }

    if (!gps) {
      alert("GPS location is required. Please wait or retry fetching GPS.");
      return;
    }

    setLoading(true);

    try {
      const now = new Date().toISOString();

      const deliveryRecord = {
        id: crypto.randomUUID(),
        bpNumber,
        noticeNumber: noticeNumber || null,
        deliveryType,
        customerName: customer.customerName,
        agentId: user?.uid || 'unknown',
        agentName: user?.displayName || user?.email || 'Agent',
        timestamp: now,
        latitude: gps.lat,
        longitude: gps.lng,
        receiverName,
        signatureBase64: '', // Signature removed
        photoBase64: photoBase64 || undefined,
        syncStatus: 'PENDING' as const
      };

      // 1. Save delivery locally
      await db.deliveries.add(deliveryRecord);

      // 2. Update master customer stats locally
      await db.customers.update(bpNumber, {
        deliveryCount: (customer.deliveryCount || 0) + 1,
        lastDeliveredAt: now,
        lastLatitude: gps.lat,
        lastLongitude: gps.lng,
        updatedAt: now,
        syncStatus: 'PENDING'
      });

      // 3. Create audit log
      await logAudit('DELIVERY_CREATED', user?.uid || 'unknown', deliveryRecord, bpNumber);

      // 4. Try cloud sync in background
      syncToCloud();

      setSuccess(true);
      setTimeout(() => {
        navigate('/agent', { replace: true });
      }, 2000);

    } catch (err) {
      console.error(err);
      alert("Failed to save delivery.");
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-green-50 flex flex-col items-center justify-center p-4 text-center">
        <CheckCircle2 className="w-20 h-20 text-green-500 mb-4" />
        <h1 className="text-2xl font-bold text-gray-900">Delivery Saved!</h1>
        <p className="text-gray-600 mt-2">The record has been saved locally and queued for sync.</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col pb-20">
      <header className="bg-white p-4 shadow-sm flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 hover:bg-gray-100 rounded-full">
          <ArrowLeft className="w-6 h-6 text-gray-700" />
        </button>
        <h1 className="text-xl font-bold text-gray-900">Confirm Delivery</h1>
      </header>

      <main className="flex-1 p-4 max-w-md mx-auto w-full space-y-4">
        {/* Customer Info Card */}
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex justify-between items-start mb-2">
            <h2 className="font-bold text-lg text-gray-900">{customer.customerName}</h2>
            <span className={`px-2 py-1 text-xs font-bold rounded-md ${deliveryType === 'BILL' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>
              {deliveryType}
            </span>
          </div>
          <p className="text-sm text-gray-600 font-mono mb-1">BP: {bpNumber}</p>
          {noticeNumber && <p className="text-sm text-gray-600 font-mono mb-2">Notice: {noticeNumber}</p>}
          <p className="text-sm text-gray-500">{customer.address}</p>
          <p className="text-sm text-gray-500">{customer.phone}</p>
        </div>

        {/* GPS Status */}
        <div className={`p-4 rounded-2xl shadow-sm border flex items-center justify-between ${gps ? 'bg-green-50 border-green-100' : 'bg-red-50 border-red-100'}`}>
          <div className="flex items-center gap-3">
            <MapPin className={`w-5 h-5 ${gps ? 'text-green-600' : 'text-red-600'}`} />
            <div>
              <p className={`text-sm font-medium ${gps ? 'text-green-800' : 'text-red-800'}`}>
                {gps ? 'GPS Captured' : 'GPS Required'}
              </p>
              {gpsError && <p className="text-xs text-red-600 mt-0.5">{gpsError}</p>}
            </div>
          </div>
          {!gps && (
            <button onClick={fetchGps} className="text-xs font-medium bg-white px-3 py-1.5 rounded-lg shadow-sm text-red-700 border border-red-200">
              Retry
            </button>
          )}
        </div>

        {/* Receiver Details */}
        <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Receiver Name</label>
            <input
              type="text"
              value={receiverName}
              onChange={(e) => setReceiverName(e.target.value)}
              className="w-full border-gray-300 rounded-xl p-3 bg-gray-50 focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Who is receiving this?"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Proof of Delivery (Photo)</label>
            {photoBase64 ? (
              <div className="relative border border-gray-300 rounded-xl overflow-hidden bg-gray-50">
                <img src={photoBase64} alt="Proof of delivery" className="w-full h-48 object-cover" />
                <button 
                  onClick={() => setPhotoBase64(null)}
                  className="absolute top-2 right-2 bg-red-500 text-white p-1.5 rounded-full shadow-md"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full border-2 border-dashed border-gray-300 rounded-xl p-6 flex flex-col items-center justify-center gap-2 text-gray-500 hover:bg-gray-50 hover:border-blue-400 hover:text-blue-600 transition-colors"
              >
                <Camera className="w-8 h-8" />
                <span className="text-sm font-medium">Capture Photo</span>
              </button>
            )}
            <input 
              type="file" 
              accept="image/*" 
              capture="environment" 
              ref={fileInputRef}
              onChange={handlePhotoCapture}
              className="hidden" 
            />
          </div>
        </div>

        <button
          onClick={handleSave}
          disabled={loading || !gps}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold mt-6 transition-colors disabled:opacity-50 shadow-lg"
        >
          {loading ? 'Saving...' : 'Save Delivery'}
        </button>
      </main>
    </div>
  );
}
