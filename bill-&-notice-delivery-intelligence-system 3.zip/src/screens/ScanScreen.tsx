import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Html5Qrcode } from 'html5-qrcode';
import { ArrowLeft, AlertCircle } from 'lucide-react';
import { db } from '../lib/db';

export default function ScanScreen() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<'AUTO' | 'MANUAL'>('AUTO');
  const [error, setError] = useState<string | null>(null);
  
  // Manual Entry State
  const [manualType, setManualType] = useState<'BILL' | 'NOTICE'>('BILL');
  const [manualBp, setManualBp] = useState('');
  const [manualNotice, setManualNotice] = useState('');

  useEffect(() => {
    let html5QrCode: Html5Qrcode | null = null;
    let isMounted = true;

    const startScanner = async () => {
      // Small delay to ensure DOM is ready
      await new Promise(resolve => setTimeout(resolve, 300));
      if (!isMounted || mode !== 'AUTO') return;

      try {
        html5QrCode = new Html5Qrcode("reader", {
          verbose: false,
          experimentalFeatures: {
            useBarCodeDetectorIfSupported: true
          }
        });
        
        await html5QrCode.start(
          { facingMode: "environment" },
          {
            fps: 10,
            qrbox: (viewfinderWidth, viewfinderHeight) => {
              // Responsive box that works for both QR and 1D
              const minEdge = Math.min(viewfinderWidth, viewfinderHeight);
              const size = Math.floor(minEdge * 0.7);
              return { width: size, height: size };
            },
            aspectRatio: 1.0,
            disableFlip: false
          },
          (decodedText) => {
            const cleanCode = decodedText.trim();
            console.log("Scanned code:", cleanCode);
            
            if (cleanCode.length === 6 || cleanCode.length === 22) {
              if (html5QrCode && html5QrCode.isScanning) {
                html5QrCode.stop().then(() => {
                  handleBarcode(cleanCode);
                }).catch((err) => {
                  console.error("Failed to stop scanner", err);
                  handleBarcode(cleanCode);
                });
              } else {
                handleBarcode(cleanCode);
              }
            } else {
              setError(`Invalid barcode length (${cleanCode.length}). Expected 6 or 22. Scanned: ${cleanCode}`);
            }
          },
          (errorMessage) => {
            // Ignore frequent scan failures
          }
        );
      } catch (err) {
        console.error("Camera start error:", err);
        if (isMounted) {
          setError("Could not start camera. Please ensure camera permissions are granted and you are using a secure connection (HTTPS).");
        }
      }
    };

    if (mode === 'AUTO') {
      startScanner();
    }

    return () => {
      isMounted = false;
      if (html5QrCode && html5QrCode.isScanning) {
        html5QrCode.stop().catch(console.error);
      }
    };
  }, [mode]);

  const handleBarcode = async (cleanCode: string) => {
    setError(null);

    if (cleanCode.length === 6) {
      // Bill
      await processDelivery('BILL', cleanCode, null);
    } else if (cleanCode.length === 22) {
      // Notice
      const noticeNum = cleanCode.substring(0, 12);
      const bpNum = cleanCode.substring(16, 22);
      await processDelivery('NOTICE', bpNum, noticeNum);
    }
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    if (!manualBp || manualBp.length !== 6) {
      setError("BP Number must be 6 digits.");
      return;
    }

    if (manualType === 'NOTICE' && (!manualNotice || manualNotice.length !== 12)) {
      setError("Notice Number must be 12 digits.");
      return;
    }

    await processDelivery(manualType, manualBp, manualType === 'NOTICE' ? manualNotice : null);
  };

  const processDelivery = async (type: 'BILL' | 'NOTICE', bp: string, notice: string | null) => {
    try {
      const customer = await db.customers.get(bp);
      
      const deliveryData = {
        bpNumber: bp,
        deliveryType: type,
        noticeNumber: notice
      };

      if (customer) {
        navigate('/confirm-delivery', { state: { ...deliveryData, customer } });
      } else {
        navigate('/create-customer', { state: deliveryData });
      }
    } catch (err) {
      console.error(err);
      setError("Database error occurred.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-white p-4 shadow-sm flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 hover:bg-gray-100 rounded-full">
          <ArrowLeft className="w-6 h-6 text-gray-700" />
        </button>
        <h1 className="text-xl font-bold text-gray-900">Scan Item</h1>
      </header>

      <main className="flex-1 p-4 max-w-md mx-auto w-full">
        <div className="flex bg-gray-200 p-1 rounded-xl mb-6">
          <button
            onClick={() => { setMode('AUTO'); setError(null); }}
            className={`flex-1 py-2 text-sm font-medium rounded-lg transition-colors ${mode === 'AUTO' ? 'bg-white shadow text-blue-600' : 'text-gray-600'}`}
          >
            Auto Scan
          </button>
          <button
            onClick={() => { setMode('MANUAL'); setError(null); }}
            className={`flex-1 py-4 text-base font-bold rounded-xl transition-all ${mode === 'MANUAL' ? 'bg-blue-600 text-white shadow-lg' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
          >
            Enter Manually
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg flex items-start gap-2 text-sm">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <p>{error}</p>
          </div>
        )}

        {mode === 'AUTO' ? (
          <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
            <div id="reader" className="w-full overflow-hidden rounded-xl"></div>
            <p className="text-center text-sm text-gray-500 mt-4">
              Point camera at the 6-digit (Bill) or 22-digit (Notice) barcode.
            </p>
          </div>
        ) : (
          <form onSubmit={handleManualSubmit} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Item Type</label>
              <select
                value={manualType}
                onChange={(e) => setManualType(e.target.value as 'BILL' | 'NOTICE')}
                className="w-full border-gray-300 rounded-xl p-3 bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
              >
                <option value="BILL">Bill</option>
                <option value="NOTICE">Notice</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">BP Number (6 digits)</label>
              <input
                type="text"
                maxLength={6}
                value={manualBp}
                onChange={(e) => setManualBp(e.target.value.replace(/\D/g, ''))}
                className="w-full border-gray-300 rounded-xl p-3 bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                placeholder="e.g. 123456"
                required
              />
            </div>

            {manualType === 'NOTICE' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Notice Number (12 digits)</label>
                <input
                  type="text"
                  maxLength={12}
                  value={manualNotice}
                  onChange={(e) => setManualNotice(e.target.value.replace(/\D/g, ''))}
                  className="w-full border-gray-300 rounded-xl p-3 bg-gray-50 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  placeholder="e.g. 123456789012"
                  required
                />
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-medium mt-6 transition-colors"
            >
              Continue
            </button>
          </form>
        )}
      </main>
    </div>
  );
}
