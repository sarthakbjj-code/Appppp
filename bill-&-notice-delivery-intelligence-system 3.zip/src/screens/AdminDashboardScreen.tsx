import React, { useEffect, useState } from 'react';
import { useAuth } from '../lib/auth';
import { useNavigate } from 'react-router-dom';
import { LogOut, Map, FileText, Database, RefreshCw, Users, CheckCircle } from 'lucide-react';
import { db } from '../lib/db';
import { syncToCloud, syncFromCloud } from '../lib/sync';
import { useLiveQuery } from 'dexie-react-hooks';

export default function AdminDashboardScreen() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [syncing, setSyncing] = useState(false);

  const todayStr = new Date().toISOString().split('T')[0];
  
  const deliveries = useLiveQuery(() => db.deliveries.toArray()) || [];
  const todayDeliveries = deliveries.filter(d => d.timestamp.startsWith(todayStr));
  
  const billsCount = todayDeliveries.filter(d => d.deliveryType === 'BILL').length;
  const noticesCount = todayDeliveries.filter(d => d.deliveryType === 'NOTICE').length;
  
  const pendingSync = useLiveQuery(() => db.deliveries.where('syncStatus').equals('PENDING').count()) || 0;
  
  // Active agents today
  const activeAgents = new Set(todayDeliveries.map(d => d.agentId)).size;

  useEffect(() => {
    const autoSync = async () => {
      setSyncing(true);
      await syncToCloud();
      await syncFromCloud();
      setSyncing(false);
    };
    autoSync();
  }, []);

  const handleSync = async () => {
    setSyncing(true);
    await syncToCloud();
    await syncFromCloud();
    setSyncing(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <header className="bg-gray-900 text-white p-4 shadow-md flex justify-between items-center sticky top-0 z-10">
        <div>
          <h1 className="text-xl font-bold">Admin Dashboard</h1>
          <p className="text-sm text-gray-400">{user?.email}</p>
        </div>
        <button onClick={logout} className="p-2 hover:bg-gray-800 rounded-full transition">
          <LogOut className="w-5 h-5" />
        </button>
      </header>

      <main className="p-4 space-y-6 max-w-4xl mx-auto">
        {/* KPIs */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col">
            <span className="text-xs text-gray-500 uppercase tracking-wider font-semibold mb-1">Today Total</span>
            <span className="text-3xl font-bold text-gray-900">{todayDeliveries.length}</span>
          </div>
          
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col">
            <span className="text-xs text-blue-500 uppercase tracking-wider font-semibold mb-1">Bills</span>
            <span className="text-3xl font-bold text-blue-700">{billsCount}</span>
          </div>

          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col">
            <span className="text-xs text-purple-500 uppercase tracking-wider font-semibold mb-1">Notices</span>
            <span className="text-3xl font-bold text-purple-700">{noticesCount}</span>
          </div>

          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col">
            <span className="text-xs text-green-500 uppercase tracking-wider font-semibold mb-1">Active Agents</span>
            <span className="text-3xl font-bold text-green-700">{activeAgents}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            onClick={() => navigate('/admin/map')}
            className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4 hover:bg-gray-50 transition-colors group"
          >
            <div className="bg-blue-100 p-4 rounded-xl group-hover:bg-blue-200 transition-colors">
              <Map className="w-8 h-8 text-blue-700" />
            </div>
            <div className="text-left">
              <h3 className="text-lg font-bold text-gray-900">Live Map</h3>
              <p className="text-sm text-gray-500">Track agents and daily routes</p>
            </div>
          </button>

          <button
            onClick={() => navigate('/admin/reports')}
            className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4 hover:bg-gray-50 transition-colors group"
          >
            <div className="bg-orange-100 p-4 rounded-xl group-hover:bg-orange-200 transition-colors">
              <FileText className="w-8 h-8 text-orange-700" />
            </div>
            <div className="text-left">
              <h3 className="text-lg font-bold text-gray-900">Reports</h3>
              <p className="text-sm text-gray-500">Export delivery data to CSV</p>
            </div>
          </button>

          <button
            onClick={() => navigate('/admin/master-data')}
            className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4 hover:bg-gray-50 transition-colors group"
          >
            <div className="bg-purple-100 p-4 rounded-xl group-hover:bg-purple-200 transition-colors">
              <Database className="w-8 h-8 text-purple-700" />
            </div>
            <div className="text-left">
              <h3 className="text-lg font-bold text-gray-900">Master Data</h3>
              <p className="text-sm text-gray-500">Manage customers & upload CSV</p>
            </div>
          </button>

          <button
            onClick={() => navigate('/admin/agents')}
            className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4 hover:bg-gray-50 transition-colors group"
          >
            <div className="bg-indigo-100 p-4 rounded-xl group-hover:bg-indigo-200 transition-colors">
              <Users className="w-8 h-8 text-indigo-700" />
            </div>
            <div className="text-left">
              <h3 className="text-lg font-bold text-gray-900">Agent Management</h3>
              <p className="text-sm text-gray-500">Add or remove field agents</p>
            </div>
          </button>

          <button
            onClick={handleSync}
            disabled={syncing}
            className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center gap-4 hover:bg-gray-50 transition-colors group disabled:opacity-50"
          >
            <div className="bg-gray-100 p-4 rounded-xl group-hover:bg-gray-200 transition-colors">
              <RefreshCw className={`w-8 h-8 text-gray-700 ${syncing ? 'animate-spin' : ''}`} />
            </div>
            <div className="text-left flex-1">
              <h3 className="text-lg font-bold text-gray-900">Sync Now</h3>
              <p className="text-sm text-gray-500">Force sync with cloud database</p>
            </div>
            {pendingSync > 0 && (
              <span className="bg-red-100 text-red-800 text-xs font-bold px-2 py-1 rounded-full">
                {pendingSync} pending
              </span>
            )}
          </button>
        </div>
      </main>
    </div>
  );
}
