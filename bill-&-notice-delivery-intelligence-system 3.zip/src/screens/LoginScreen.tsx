import React from 'react';
import { useAuth } from '../lib/auth';
import { Shield, UserCircle } from 'lucide-react';

export default function LoginScreen() {
  const { login, error } = useAuth();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl p-8 space-y-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900">Bill & Notice Delivery</h1>
          <p className="text-gray-500 mt-2">Sign in to continue</p>
        </div>

        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm text-center">
            {error}
          </div>
        )}

        <div className="space-y-4">
          <button
            onClick={() => login('AGENT')}
            className="w-full flex items-center justify-center gap-3 bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-xl font-medium transition-colors"
          >
            <UserCircle className="w-5 h-5" />
            Agent Login
          </button>

          <button
            onClick={() => login('ADMIN')}
            className="w-full flex items-center justify-center gap-3 bg-gray-800 hover:bg-gray-900 text-white py-3 px-4 rounded-xl font-medium transition-colors"
          >
            <Shield className="w-5 h-5" />
            Admin Login
          </button>
        </div>
      </div>
    </div>
  );
}
