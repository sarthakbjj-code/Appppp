import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Download, ArrowLeft, Search, Upload, Plus, Edit2, RefreshCw } from 'lucide-react';
import { db, CustomerMaster } from '../lib/db';
import { useLiveQuery } from 'dexie-react-hooks';
import Papa from 'papaparse';
import { logAudit, syncToCloud, syncFromCloud, clearAndUploadMasterData } from '../lib/sync';
import { useAuth } from '../lib/auth';

export default function MasterDataScreen() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [search, setSearch] = useState('');
  const [uploading, setUploading] = useState(false);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      setSyncing(true);
      await syncFromCloud();
      setSyncing(false);
    };
    loadData();
  }, []);

  const customers = useLiveQuery(
    () => db.customers
      .filter(c => c.bpNumber.includes(search) || c.customerName.toLowerCase().includes(search.toLowerCase()))
      .limit(50)
      .toArray(),
    [search]
  ) || [];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      transformHeader: (header) => header.trim(),
      complete: async (results) => {
        try {
          const newCustomers: CustomerMaster[] = [];
          for (const row of results.data as any[]) {
            // Expected columns: BP Number, Name, Address, PHONE_1, PHONE_2
            const bpNumber = row['BP Number']?.toString().trim();
            if (!bpNumber || bpNumber.length !== 6) continue;

            const phone1 = row['PHONE_1']?.toString().trim() || '';
            const phone2 = row['PHONE_2']?.toString().trim() || '';
            const phone = [phone1, phone2].filter(Boolean).join(', ');

            newCustomers.push({
              bpNumber,
              customerName: row['Name'] || 'Unknown',
              address: row['Address'] || '',
              phone: phone || row['Phone Number'] || '',
              deliveryCount: 0,
              lastDeliveredAt: null,
              lastLatitude: null,
              lastLongitude: null,
              createdBy: user?.uid || 'admin',
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
              syncStatus: 'PENDING'
            });
          }

          if (newCustomers.length > 0) {
            await clearAndUploadMasterData(newCustomers);
            await logAudit('MASTER_DATA_UPLOADED', user?.uid || 'admin', { count: newCustomers.length });
            alert(`Successfully imported ${newCustomers.length} customers.`);
          } else {
            alert("No valid records found. Ensure columns are: BP Number, Name, Address, PHONE_1, PHONE_2");
          }
        } catch (err) {
          console.error(err);
          alert("Error importing data.");
        } finally {
          setUploading(false);
          if (e.target) e.target.value = '';
        }
      },
      error: (error) => {
        console.error(error);
        alert("Error parsing CSV file.");
        setUploading(false);
      }
    });
  };

  const handleDownloadData = async () => {
    try {
      const allCustomers = await db.customers.toArray();
      if (allCustomers.length === 0) {
        alert("No data to download.");
        return;
      }

      const csvData = allCustomers.map(c => ({
        'BP Number': c.bpNumber,
        'Name': c.customerName,
        'Address': c.address,
        'Phone': c.phone,
        'Deliveries': c.deliveryCount
      }));

      const csv = Papa.unparse(csvData);
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `master_data_${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
      alert("Error downloading data.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col pb-20">
      <header className="bg-gray-900 text-white p-4 shadow-md flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 hover:bg-gray-800 rounded-full">
          <ArrowLeft className="w-6 h-6 text-gray-300" />
        </button>
        <h1 className="text-xl font-bold">Master Data</h1>
      </header>

      <main className="flex-1 p-4 max-w-4xl mx-auto w-full space-y-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search by BP Number or Name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full border-gray-300 rounded-xl pl-10 pr-4 py-3 bg-white shadow-sm focus:ring-2 focus:ring-blue-500 outline-none"
            />
          </div>
          
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={async () => {
                setSyncing(true);
                await syncFromCloud();
                setSyncing(false);
              }}
              disabled={syncing}
              className="bg-white border border-gray-300 text-gray-700 px-4 py-3 rounded-xl shadow-sm flex items-center gap-2 hover:bg-gray-50 transition-colors whitespace-nowrap disabled:opacity-50"
            >
              <RefreshCw className={`w-5 h-5 ${syncing ? 'animate-spin' : ''}`} />
              {syncing ? 'Syncing...' : 'Sync'}
            </button>
            <button
              onClick={handleDownloadData}
              className="bg-white border border-gray-300 text-gray-700 px-4 py-3 rounded-xl shadow-sm flex items-center gap-2 hover:bg-gray-50 transition-colors whitespace-nowrap"
            >
              <Download className="w-5 h-5" />
              Download
            </button>
            <label className="bg-white border border-gray-300 text-gray-700 px-4 py-3 rounded-xl shadow-sm flex items-center gap-2 hover:bg-gray-50 cursor-pointer transition-colors whitespace-nowrap">
              <Upload className="w-5 h-5" />
              {uploading ? 'Uploading...' : 'Upload CSV'}
              <input type="file" accept=".csv" className="hidden" onChange={handleFileUpload} disabled={uploading} />
            </label>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-gray-500">
              <thead className="text-xs text-gray-700 uppercase bg-gray-50 border-b">
                <tr>
                  <th className="px-6 py-3">BP Number</th>
                  <th className="px-6 py-3">Name</th>
                  <th className="px-6 py-3">Address</th>
                  <th className="px-6 py-3">Phone</th>
                  <th className="px-6 py-3">Deliveries</th>
                </tr>
              </thead>
              <tbody>
                {customers.map((c) => (
                  <tr key={c.bpNumber} className="bg-white border-b hover:bg-gray-50">
                    <td className="px-6 py-4 font-medium text-gray-900">{c.bpNumber}</td>
                    <td className="px-6 py-4">{c.customerName}</td>
                    <td className="px-6 py-4 truncate max-w-[200px]" title={c.address}>{c.address}</td>
                    <td className="px-6 py-4">{c.phone}</td>
                    <td className="px-6 py-4">
                      <span className="bg-blue-100 text-blue-800 text-xs font-bold px-2 py-1 rounded-full">
                        {c.deliveryCount}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {customers.length === 0 && (
              <div className="p-8 text-center text-sm text-gray-500">
                No customers found. Try searching or uploading a CSV.
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
