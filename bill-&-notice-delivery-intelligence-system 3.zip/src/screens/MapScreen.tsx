import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, User, Calendar } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { db } from '../lib/db';
import { useLiveQuery } from 'dexie-react-hooks';

// Fix Leaflet default icon issue
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const createCustomIcon = (color: string, number?: number) => {
  return L.divIcon({
    className: 'custom-div-icon',
    html: `<div style="background-color: ${color}; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; border: 2px solid white; box-shadow: 0 2px 5px rgba(0,0,0,0.3);">${number || ''}</div>`,
    iconSize: [30, 30],
    iconAnchor: [15, 15]
  });
};

function MapUpdater({ positions }: { positions: [number, number][] }) {
  const map = useMap();
  useEffect(() => {
    if (positions.length > 0) {
      const bounds = L.latLngBounds(positions);
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [map, positions]);
  return null;
}

export default function MapScreen() {
  const navigate = useNavigate();
  const [selectedAgent, setSelectedAgent] = useState<string>('ALL');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);

  const deliveries = useLiveQuery(() => db.deliveries.toArray()) || [];
  
  // Filter and sort
  const filteredDeliveries = deliveries
    .filter(d => d.timestamp.startsWith(selectedDate) && (selectedAgent === 'ALL' || d.agentId === selectedAgent))
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  const uniqueAgents = Array.from(new Set(deliveries.map(d => d.agentId)));

  const routePositions: [number, number][] = filteredDeliveries.map(d => [d.latitude, d.longitude]);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <header className="bg-gray-900 text-white p-4 shadow-md flex items-center gap-4 sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="p-2 -ml-2 hover:bg-gray-800 rounded-full">
          <ArrowLeft className="w-6 h-6 text-gray-300" />
        </button>
        <h1 className="text-xl font-bold">Live Map & Routes</h1>
      </header>

      <div className="bg-white p-4 shadow-sm border-b border-gray-200 flex flex-wrap gap-4 z-10">
        <div className="flex-1 min-w-[200px]">
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1 flex items-center gap-1">
            <User className="w-3 h-3" /> Agent
          </label>
          <select
            value={selectedAgent}
            onChange={(e) => setSelectedAgent(e.target.value)}
            className="w-full border-gray-300 rounded-lg p-2 bg-gray-50 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
          >
            <option value="ALL">All Agents</option>
            {uniqueAgents.map(agent => (
              <option key={agent} value={agent}>{agent}</option>
            ))}
          </select>
        </div>

        <div className="flex-1 min-w-[200px]">
          <label className="block text-xs font-bold text-gray-500 uppercase mb-1 flex items-center gap-1">
            <Calendar className="w-3 h-3" /> Date
          </label>
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-full border-gray-300 rounded-lg p-2 bg-gray-50 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>
      </div>

      <main className="flex-1 relative z-0">
        <MapContainer 
          center={routePositions.length > 0 ? routePositions[0] : [20.5937, 78.9629]} 
          zoom={routePositions.length > 0 ? 13 : 5} 
          style={{ height: '100%', width: '100%' }}
        >
          <MapUpdater positions={routePositions} />
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          
          {selectedAgent !== 'ALL' && routePositions.length > 0 && (
            <Polyline positions={routePositions} color="#3b82f6" weight={4} opacity={0.7} />
          )}

          {filteredDeliveries.map((delivery, index) => (
            <Marker 
              key={delivery.id || index} 
              position={[delivery.latitude, delivery.longitude]}
              icon={createCustomIcon(delivery.deliveryType === 'BILL' ? '#3b82f6' : '#a855f7', index + 1)}
            >
              <Popup>
                <div className="text-sm">
                  <p className="font-bold">{delivery.customerName}</p>
                  <p>BP: {delivery.bpNumber}</p>
                  <p>Type: {delivery.deliveryType}</p>
                  <p>Time: {new Date(delivery.timestamp).toLocaleTimeString()}</p>
                  <p>Agent: {delivery.agentId}</p>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </main>
    </div>
  );
}
