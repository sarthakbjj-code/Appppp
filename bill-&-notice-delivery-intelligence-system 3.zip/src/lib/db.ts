import Dexie, { Table } from 'dexie';

export interface CustomerMaster {
  bpNumber: string;
  customerName: string;
  address: string;
  phone: string;
  deliveryCount: number;
  lastDeliveredAt: string | null;
  lastLatitude: number | null;
  lastLongitude: number | null;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  syncStatus: 'PENDING' | 'SYNCED';
}

export interface DeliveryRecord {
  id?: string;
  bpNumber: string;
  noticeNumber: string | null;
  deliveryType: 'BILL' | 'NOTICE';
  customerName: string;
  agentId: string;
  agentName: string;
  timestamp: string;
  latitude: number;
  longitude: number;
  receiverName: string;
  signatureBase64: string;
  photoBase64?: string;
  syncStatus: 'PENDING' | 'SYNCED';
}

export interface AuditLog {
  id?: string;
  eventType: string;
  bpNumber?: string;
  agentId: string;
  timestamp: string;
  payload: any;
  syncStatus: 'PENDING' | 'SYNCED';
}

export class AppDatabase extends Dexie {
  customers!: Table<CustomerMaster, string>;
  deliveries!: Table<DeliveryRecord, string>;
  auditLogs!: Table<AuditLog, string>;

  constructor() {
    super('BillNoticeDeliveryDB');
    this.version(2).stores({
      customers: 'bpNumber, syncStatus',
      deliveries: '++id, bpNumber, syncStatus, timestamp',
      auditLogs: '++id, syncStatus, timestamp'
    });
  }
}

export const db = new AppDatabase();
