import { db, CustomerMaster } from './db';
import { dbRealtime, isFirebaseConfigured, auth } from './firebase';
import { ref, get, set, update, remove, child } from 'firebase/database';

function sanitizeForRTDB(obj: any): any {
  if (obj === null || obj === undefined) return null;
  if (typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) {
    return obj.map(sanitizeForRTDB);
  }
  const sanitized: any = {};
  Object.keys(obj).forEach(key => {
    sanitized[key] = sanitizeForRTDB(obj[key]);
  });
  return sanitized;
}

export async function syncToCloud() {
  if (!isFirebaseConfigured || !auth.currentUser) return;

  try {
    const pendingCustomers = await db.customers.where('syncStatus').equals('PENDING').toArray();
    const pendingDeliveries = await db.deliveries.where('syncStatus').equals('PENDING').toArray();
    const pendingLogs = await db.auditLogs.where('syncStatus').equals('PENDING').toArray();

    if (pendingCustomers.length === 0 && pendingDeliveries.length === 0 && pendingLogs.length === 0) {
      return;
    }

    // RTDB supports multi-path updates
    let updates: Record<string, any> = {};
    let operationCount = 0;
    const BATCH_LIMIT = 450;

    const commitUpdatesIfNeeded = async () => {
      if (operationCount >= BATCH_LIMIT) {
        await update(ref(dbRealtime), updates);
        updates = {};
        operationCount = 0;
      }
    };

    for (const customer of pendingCustomers) {
      updates[`customers_master/${customer.bpNumber}`] = sanitizeForRTDB({ ...customer, syncStatus: 'SYNCED' });
      operationCount++;
      await commitUpdatesIfNeeded();
    }

    for (const delivery of pendingDeliveries) {
      const dbId = delivery.id || crypto.randomUUID();
      delivery.id = dbId;
      updates[`deliveries/${dbId}`] = sanitizeForRTDB({ ...delivery, syncStatus: 'SYNCED' });
      operationCount++;
      await commitUpdatesIfNeeded();
    }

    for (const log of pendingLogs) {
      const dbId = log.id || crypto.randomUUID();
      log.id = dbId;
      updates[`audit_logs/${dbId}`] = sanitizeForRTDB({ ...log, syncStatus: 'SYNCED' });
      operationCount++;
      await commitUpdatesIfNeeded();
    }

    if (operationCount > 0) {
      await update(ref(dbRealtime), updates);
    }

    // Mark as synced locally
    await db.transaction('rw', db.customers, db.deliveries, db.auditLogs, async () => {
      for (const customer of pendingCustomers) {
        await db.customers.update(customer.bpNumber, { syncStatus: 'SYNCED' });
      }
      for (const delivery of pendingDeliveries) {
        if (delivery.id) await db.deliveries.update(delivery.id, { syncStatus: 'SYNCED' });
      }
      for (const log of pendingLogs) {
        if (log.id) await db.auditLogs.update(log.id, { syncStatus: 'SYNCED' });
      }
    });

  } catch (error: any) {
    console.error("Sync failed:", error);
    if (error.message && error.message.includes('permission_denied')) {
      alert("Sync failed: You do not have permission to write to the database. Please check your Firebase Security Rules.");
    } else {
      alert("Sync failed: " + (error.message || "Unknown error"));
    }
  }
}

export async function clearAndUploadMasterData(newCustomers: CustomerMaster[]) {
  if (!isFirebaseConfigured) {
    await db.customers.clear();
    await db.customers.bulkPut(newCustomers);
    return;
  }

  try {
    // 1. Delete all existing customers from RTDB
    await remove(ref(dbRealtime, 'customers_master'));

    // 2. Clear local DB
    await db.customers.clear();

    // 3. Put new customers locally (as PENDING)
    await db.customers.bulkPut(newCustomers);

    // 4. Sync to cloud (which will upload the new ones in batches)
    await syncToCloud();

  } catch (error: any) {
    console.error("Failed to clear and upload master data:", error);
    if (error.message && error.message.includes('permission_denied')) {
      alert("Upload failed: You do not have permission to delete or write to the database. Please check your Firebase Security Rules.");
    } else {
      alert("Upload failed: " + error.message);
    }
    throw error;
  }
}

export async function syncFromCloud() {
  if (!isFirebaseConfigured || !auth.currentUser) return;
  try {
    const customersSnap = await get(ref(dbRealtime, 'customers_master'));
    const deliveriesSnap = await get(ref(dbRealtime, 'deliveries'));
    const logsSnap = await get(ref(dbRealtime, 'audit_logs'));

    const customers: any[] = [];
    if (customersSnap.exists()) {
      customersSnap.forEach(child => {
        customers.push(child.val());
      });
    }

    const deliveries: any[] = [];
    if (deliveriesSnap.exists()) {
      deliveriesSnap.forEach(child => {
        deliveries.push(child.val());
      });
    }

    const auditLogs: any[] = [];
    if (logsSnap.exists()) {
      logsSnap.forEach(child => {
        auditLogs.push(child.val());
      });
    }

    await db.transaction('rw', db.customers, db.deliveries, db.auditLogs, async () => {
      for (const c of customers) {
        await db.customers.put({ ...c, syncStatus: 'SYNCED' });
      }
      for (const d of deliveries) {
        await db.deliveries.put({ ...d, syncStatus: 'SYNCED' });
      }
      for (const a of auditLogs) {
        await db.auditLogs.put({ ...a, syncStatus: 'SYNCED' });
      }
    });
  } catch (error: any) {
    console.error("Sync from cloud failed:", error);
    if (error.message && error.message.includes('permission_denied')) {
      alert("Sync failed: You do not have permission to read from the database. Please check your Firebase Security Rules.");
    }
  }
}

export async function logAudit(eventType: string, agentId: string, payload: any, bpNumber?: string) {
  await db.auditLogs.add({
    id: crypto.randomUUID(),
    eventType,
    agentId,
    timestamp: new Date().toISOString(),
    payload,
    bpNumber,
    syncStatus: 'PENDING'
  });
  syncToCloud(); // Try to sync immediately in background
}
