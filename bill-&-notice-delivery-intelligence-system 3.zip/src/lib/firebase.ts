/// <reference types="vite/client" />
import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getDatabase } from 'firebase/database';
import { getAnalytics } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: "AIzaSyDMYpDKTNqndwj89zKpkMNzEccmCEKZkmw",
  authDomain: "ai-studio-ae1d5.firebaseapp.com",
  databaseURL: "https://ai-studio-ae1d5-default-rtdb.firebaseio.com/",
  projectId: "ai-studio-ae1d5",
  storageBucket: "ai-studio-ae1d5.firebasestorage.app",
  messagingSenderId: "1044411685178",
  appId: "1:1044411685178:web:83d2171fcb74db97335803",
  measurementId: "G-3Q54X7PFF6"
};

export const app = initializeApp(firebaseConfig);
export const analytics = typeof window !== 'undefined' ? getAnalytics(app) : null;
export const auth = getAuth(app);
export const dbRealtime = getDatabase(app);
export const googleProvider = new GoogleAuthProvider();

export const isFirebaseConfigured = true;

