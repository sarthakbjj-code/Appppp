import { useEffect } from 'react';
import { useAuth } from './auth';
import { db } from './db';
import { syncToCloud } from './sync';

export function useLiveLocation() {
  const { user, role } = useAuth();

  useEffect(() => {
    if (role !== 'AGENT' || !user) return;

    let watchId: number;

    const startTracking = () => {
      if (!navigator.geolocation) return;

      watchId = navigator.geolocation.watchPosition(
        async (position) => {
          try {
            const locationRecord = {
              agentId: user.uid,
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              timestamp: new Date().toISOString(),
              isOnline: true,
              syncStatus: 'PENDING' as const
            };

            // We can store this in a separate table or just send it directly to Firebase
            // To keep it simple and offline-friendly, we'll use the auditLogs table with a specific event type
            await db.auditLogs.add({
              eventType: 'LIVE_LOCATION',
              agentId: user.uid,
              timestamp: locationRecord.timestamp,
              payload: locationRecord,
              syncStatus: 'PENDING'
            });

            syncToCloud();
          } catch (err) {
            console.error("Failed to save live location:", err);
          }
        },
        (error) => {
          console.error("Live location error:", error);
        },
        { enableHighAccuracy: true, maximumAge: 10000, timeout: 5000 }
      );
    };

    startTracking();

    return () => {
      if (watchId) navigator.geolocation.clearWatch(watchId);
    };
  }, [user, role]);
}
