import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth, googleProvider, isFirebaseConfigured, dbRealtime } from './firebase';
import { signInWithPopup, signOut, onAuthStateChanged, User } from 'firebase/auth';
import { ref, get, set, child } from 'firebase/database';
import { logAudit } from './sync';

export type Role = 'ADMIN' | 'AGENT' | null;

interface AuthContextType {
  user: User | null;
  role: Role;
  loading: boolean;
  login: (requestedRole: 'ADMIN' | 'AGENT') => Promise<void>;
  logout: () => Promise<void>;
  error: string | null;
}

export const AuthContext = createContext<AuthContextType>({} as any);

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<Role>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isFirebaseConfigured) {
      // Offline/Demo mode: Check local storage
      const storedUser = localStorage.getItem('demo_user');
      const storedRole = localStorage.getItem('demo_role');
      if (storedUser && storedRole) {
        setUser(JSON.parse(storedUser));
        setRole(storedRole as Role);
      }
      setLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          // Check role in RTDB
          const safeEmail = firebaseUser.email!.replace(/[.#$[\]]/g, '_');
          const userRef = ref(dbRealtime, `users/${safeEmail}`);
          const userSnapshot = await get(userRef);
          
          if (userSnapshot.exists()) {
            const userData = userSnapshot.val();
            const storedRole = sessionStorage.getItem('activeRole');
            const activeRole = (userData.role === 'ADMIN' && storedRole === 'AGENT') ? 'AGENT' : userData.role;
            setRole(activeRole);
            setUser(firebaseUser);
          } else if (firebaseUser.email === 'sarthakbjj@gmail.com') {
            // Bootstrap first admin
            await set(userRef, {
              email: firebaseUser.email,
              role: 'ADMIN',
              createdAt: new Date().toISOString()
            });
            const storedRole = sessionStorage.getItem('activeRole');
            const activeRole = storedRole === 'AGENT' ? 'AGENT' : 'ADMIN';
            setRole(activeRole as Role);
            setUser(firebaseUser);
          } else {
            // If user not found in authorized list, sign out
            await signOut(auth);
            setUser(null);
            setRole(null);
            setError("Email not authorized. Please contact admin.");
          }
        } catch (err) {
          console.error("Error fetching user role:", err);
          setError("Failed to verify authorization.");
        }
      } else {
        setUser(null);
        setRole(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (requestedRole: 'ADMIN' | 'AGENT') => {
    setError(null);
    if (!isFirebaseConfigured) {
      // Demo mode
      const demoEmail = prompt("Enter your email (Demo Mode):", "sarthakbjj@gmail.com");
      if (!demoEmail) return;
      
      // Hardcode admin for the provided email, otherwise agent
      const actualRole = demoEmail === 'sarthakbjj@gmail.com' ? 'ADMIN' : 'AGENT';
      
      if (requestedRole !== actualRole && actualRole !== 'ADMIN') {
         setError(`You are not authorized as ${requestedRole}`);
         return;
      }

      const mockUser = { uid: 'demo-uid-' + Date.now(), email: demoEmail, displayName: demoEmail.split('@')[0] } as User;
      setUser(mockUser);
      setRole(actualRole);
      localStorage.setItem('demo_user', JSON.stringify(mockUser));
      localStorage.setItem('demo_role', actualRole);
      await logAudit('LOGIN_SUCCESS', mockUser.uid, { email: demoEmail, role: actualRole });
      return;
    }

    try {
      const result = await signInWithPopup(auth, googleProvider);
      const email = result.user.email;
      if (!email) throw new Error("No email found");

      const safeEmail = email.replace(/[.#$[\]]/g, '_');
      const userRef = ref(dbRealtime, `users/${safeEmail}`);
      const userSnapshot = await get(userRef);
      let userData;

      if (!userSnapshot.exists()) {
        if (email === 'sarthakbjj@gmail.com') {
          userData = { email, role: 'ADMIN', createdAt: new Date().toISOString() };
          await set(userRef, userData);
        } else {
          await signOut(auth);
          await logAudit('LOGIN_FAILED', result.user.uid, { email, reason: 'Not authorized' });
          setError("Email not authorized. Please contact admin.");
          return;
        }
      } else {
        userData = userSnapshot.val();
      }

      if (requestedRole === 'ADMIN' && userData.role !== 'ADMIN') {
        await signOut(auth);
        await logAudit('LOGIN_FAILED', result.user.uid, { email, reason: 'Requested ADMIN but is AGENT' });
        setError("You are not authorized as ADMIN.");
        return;
      }

      const activeRole = requestedRole === 'AGENT' ? 'AGENT' : userData.role;
      sessionStorage.setItem('activeRole', activeRole);
      setRole(activeRole);
      setUser(result.user);
      await logAudit('LOGIN_SUCCESS', result.user.uid, { email, role: activeRole });
    } catch (err: any) {
      console.error("Login error:", err);
      // Ignore user-cancelled popup errors
      if (err.code === 'auth/cancelled-popup-request' || err.code === 'auth/popup-closed-by-user') {
        return;
      }
      setError(err.message || "Failed to login");
    }
  };

  const logout = async () => {
    if (user) {
      await logAudit('LOGOUT', user.uid, { email: user.email });
    }
    sessionStorage.removeItem('activeRole');
    if (!isFirebaseConfigured) {
      localStorage.removeItem('demo_user');
      localStorage.removeItem('demo_role');
      setUser(null);
      setRole(null);
      return;
    }
    await signOut(auth);
    setUser(null);
    setRole(null);
  };

  return (
    <AuthContext.Provider value={{ user, role, loading, login, logout, error }}>
      {children}
    </AuthContext.Provider>
  );
};
